/*Programmer: Matthew Moore
Description: 20s
Date: 1-9-19
*/
#include <iostream>
using namespace std;

int main()
{
	for (int i = 20; i < 181; i += 20)
	{
		cout << i << '\t';
	}

	cout << endl;

	system("pause");
	return 0;
}
